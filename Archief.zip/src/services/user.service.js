const database = require('../dao/inmem-db')
const logger = require('../util/logger')

const userService = {
    create: (user, callback) => {
        logger.info('create user', user);
        // Check if the email already exists
        database.findByEmail(user.email, (err, existingUser) => {
            if (err) {
                callback(err, null);
                return;
            }
            if (existingUser) {
                callback({ status: 400, message: "Email already exists" }, null);
                return;
            }
            // Add the user if email is not taken
            database.add(user, (err, data) => {
                if (err) {
                    logger.info('error creating user: ', err.message || 'unknown error');
                    callback(err, null);
                } else {
                    logger.trace(`User created with id ${data.id}.`);
                    callback(null, {
                        message: `User created with id ${data.id}.`,
                        data: data
                    });
                }
            });
        });
    },

    update: (userId, updates, callback) => {
        logger.info(`update user ${userId}`, updates);
        database.update(userId, updates, (err, updatedUser) => {
            if (err) {
                callback(err, null);
                return;
            }
            callback(null, {
                message: `User ${userId} updated successfully.`,
                data: updatedUser
            });
        });
    },
    
    delete: (userId, callback) => {
        logger.info(`delete user ${userId}`);
        database.remove(userId, (err) => {
            if (err) {
                callback(err, null);
                return;
            }
            callback(null, {
                message: `User ${userId} deleted successfully.`
            });
        });
    },
    

    getAll: (filters, callback) => {
        logger.info('getAll with filters', filters);
        database.getAll((err, users) => {
            if (err) {
                callback(err, null);
                return;
            }
            // Filter users based on the filters provided
            const filteredUsers = users.filter(user => {
                let isValid = true;
                for (let key in filters) {
                    if (user[key] !== filters[key]) {
                        isValid = false;
                    }
                }
                return isValid;
            });
            callback(null, {
                message: `Found ${filteredUsers.length} users.`,
                data: filteredUsers
            });
        });
    }    
}

module.exports = userService
