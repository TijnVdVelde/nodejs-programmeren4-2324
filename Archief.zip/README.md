# Nodejs Programmeren 4 Express server

Hier komt een korte introductie.

## Installing

To install, run `npm install`.

## Running

To run the server in your local development environment, type `npm run dev`.

## Run the tests

To run the tests, type `npm test`.
